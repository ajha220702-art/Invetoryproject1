# Inventory Tracker

Web application for BoM (bill-of-material) stock control, built from BRD v1.1 and SDD v1.0 (Group 7, DPMG).

**Stack:** Python 3.10+, Flask 3, SQLite (standard library `sqlite3`), server-rendered Jinja templates, one CSS file. No external services.

## Features (requirement coverage)

| BRD FR | Feature | Where |
|---|---|---|
| FR1, FR2 | Login with hashed-password verification; invalid credentials stay on the login page with an error | `blueprints/auth.py`, `services/users.py` |
| FR3, FR4 | Add BoM; entered balance is stored as opening **and** current balance | `services/boms.create` |
| FR5, FR14 | Edit BoM — Inventory Manager / System Administrator only (HTTP 403 otherwise) | `blueprints/boms.edit`, `security.roles_required` |
| FR6, FR15 | Delete BoM (soft-delete, removed from active list) — same roles | `services/boms.delete` |
| FR7 | Mandatory-field and type validation before save | `services/boms.validate` |
| FR8, FR9 | Stock-in / stock-out with atomic balance update | `services/transactions.record` |
| FR10 | Stock-out exceeding balance is rejected, balance unchanged; DB `CHECK` prevents negatives | `services/transactions.record`, `schema.sql` |
| FR11 | Warning banner and Low-Stock screen when balance ≤ safety stock | `blueprints/stock.py`, `blueprints/low_stock.py` |
| FR12 | Search by BoM name (or ID) | `services/boms.search` |
| FR13 | Duplicate BoM ID rejected (app check + PK constraint) | `services/boms.create` |
| FR16 | Filter BoM list by stock status (All / Available / Low Stock) | `services/boms.search` |
| FR17 | Logout ends session, returns to login | `blueprints/auth.logout` |
| Scope: auto-PO | Purchase order auto-generated when balance ≤ safety stock; one open PO per BoM; manager review | `services/purchase_orders.py` |

Non-functional: passwords hashed with Werkzeug (NFR6); write-then-read after transactions (NFR2); `BEGIN IMMEDIATE` transactions with rollback (NFR8, also serialises concurrent writers — R-03); BoM list paginated above 500 rows (NFR1); one module per screen and entity (NFR9); CSRF protection on every POST; sidebar navigation on every screen (NFR3).

## Setup

```bash
cd inventory_tracker
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env
# Edit .env: set SECRET_KEY (e.g. python -c "import secrets; print(secrets.token_hex(32))")
#            and SEED_ADMIN_PASSWORD

export FLASK_APP=run.py          # Windows PowerShell: $env:FLASK_APP="run.py"
flask seed                       # creates tables + the System Administrator account
flask add-user priya "Inventory Manager"   # prompts for a password; repeat per user/role
python run.py                    # http://127.0.0.1:5000
```

Roles: `Inventory Staff`, `Inventory Manager`, `Business Owner`, `System Administrator`.

## Run the tests

```bash
python -m pytest -q
```

15 acceptance tests, one or more per functional requirement, using an in-memory SQLite database.

## Project layout

```
inventory_tracker/
├── run.py                 # dev entry point
├── config.py              # settings from environment (.env)
├── requirements.txt
├── .env.example
├── app/
│   ├── __init__.py        # application factory
│   ├── db.py              # SQLite connection + CLI (init-db, seed, add-user)
│   ├── schema.sql         # tables: users, boms, stock_transactions, purchase_orders
│   ├── security.py        # login_required, roles_required, CSRF
│   ├── services/          # business logic, one module per entity
│   │   └── users.py  boms.py  transactions.py  purchase_orders.py
│   ├── blueprints/        # routes, one module per screen
│   │   └── auth.py  dashboard.py  boms.py  stock.py  low_stock.py  purchase_orders.py
│   ├── templates/         # Jinja screens (+ _macros.html for the stock bar / form fields)
│   └── static/style.css
└── tests/
    ├── conftest.py
    └── test_app.py
```

## Design decisions (from SDD §8 open items)

| Item | Implemented as | Change it in |
|---|---|---|
| Reorder quantity | Fixed rule: suggest `safety_stock × REORDER_MULTIPLIER − current_balance` (min 1) | `REORDER_MULTIPLIER` in `.env`; `purchase_orders.suggested_quantity` |
| PO workflow | Review-only: `Generated` → `Reviewed` by Manager/Owner/Admin | `security.PO_REVIEW_ROLES` |
| Categories | Predefined static list | `Config.CATEGORIES` |
| Concurrency | `BEGIN IMMEDIATE` per stock transaction | `transactions.record` |
| Data migration | Manual entry only (no bulk import) | — |
| Delete semantics | Soft delete (`is_active = 0`) so transaction and PO history is kept | `boms.delete` |

## Production notes

- Run behind a WSGI server: `pip install gunicorn && gunicorn -w 2 "app:create_app()"`.
- Set `SESSION_COOKIE_SECURE=True` in `config.py` when serving over HTTPS.
- Back up the SQLite file at `DATABASE_PATH`. To move to PostgreSQL/Supabase later, the SQL in `services/` is standard; only `db.py` needs a driver swap.
